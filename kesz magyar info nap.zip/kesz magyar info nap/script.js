function bek()
{
    let embik = parseInt(document.getElementById("fo").value)
    let hely = parseInt(document.adatok.rad.value)
    let ossz = 10000

    ossz = (ossz+ hely)*embik
    document.getElementById("ki").innerHTML = "Fizetendő összeg:"+ossz
}